
import { useState } from "react";

export default function Home() {
  const [type, setType] = useState("ผนัง");
  const [packageType, setPackageType] = useState("ปกติ");
  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");

  const prices = {
    "ผนัง": { "ปกติ": 500, "พรีเมี่ยม": 800 },
    "แขวน": { "ปกติ": 1250, "พรีเมี่ยม": 1500 },
    "สี่ทิศทาง": { "ปกติ": 1500 },
    "เปลือย": { "ปกติ": 1200 }
  };

  const unitPrice = prices[type][packageType] || 0;
  const total = unitPrice * quantity;
  const discountRate = quantity >= 8 ? 0.15 : quantity >= 3 ? 0.1 : 0;
  const discount = total * discountRate;
  const finalPrice = total - discount;

  const message = `❄️ ขอบคุณค่ะคุณ${customerName}\n` +
    `สรุปรายการล้างแอร์ ${type} ${quantity} เครื่อง\n` +
    `📍 ที่อยู่: ${address}\n📞 เบอร์โทร: ${phone}\n` +
    `💧 แพ็กเกจ: ${packageType}\n\n` +
    `💰 ราคาปกติ: ${unitPrice} × ${quantity} = ${total.toLocaleString()} บาท\n` +
    `🎉 ส่วนลด: ${discount.toLocaleString()} บาท (${discountRate * 100}%)\n` +
    `💸 ราคาหลังหักส่วนลด: ${finalPrice.toLocaleString()} บาท\n\n` +
    `🎁 ฟรี! เติมน้ำยาแอร์ (ไม่เกิน 10 psi)\n🎁 ฟรี! ลงน้ำยาฆ่าเชื้อ ลดกลิ่นอับ\n\n` +
    `📅 กรุณาแจ้งวันและเวลาที่สะดวกให้ทีมช่างเข้าให้บริการค่ะ 😊`;

  return (
    <main style={{ padding: 20, fontFamily: "sans-serif" }}>
      <h2>คำนวณราคาล้างแอร์</h2>
      <div>
        <label>ชื่อลูกค้า:</label><br/>
        <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} /><br/><br/>

        <label>ที่อยู่:</label><br/>
        <input value={address} onChange={(e) => setAddress(e.target.value)} /><br/><br/>

        <label>เบอร์โทร:</label><br/>
        <input value={phone} onChange={(e) => setPhone(e.target.value)} /><br/><br/>

        <label>ประเภทแอร์:</label><br/>
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="ผนัง">ผนัง</option>
          <option value="แขวน">แขวน</option>
          <option value="สี่ทิศทาง">สี่ทิศทาง</option>
          <option value="เปลือย">เปลือย</option>
        </select><br/><br/>

        <label>แพ็กเกจ:</label><br/>
        <select value={packageType} onChange={(e) => setPackageType(e.target.value)}>
          <option value="ปกติ">ปกติ</option>
          {(type === "ผนัง" || type === "แขวน") && <option value="พรีเมี่ยม">พรีเมี่ยม</option>}
        </select><br/><br/>

        <label>จำนวนเครื่อง:</label><br/>
        <input type="number" value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} /><br/><br/>

        <label>ข้อความตอบลูกค้า:</label><br/>
        <textarea rows={10} style={{ width: '100%' }} readOnly value={message} />
      </div>
    </main>
  );
}
